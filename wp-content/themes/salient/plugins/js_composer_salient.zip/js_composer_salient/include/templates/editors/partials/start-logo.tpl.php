<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>

<div class="vc_welcome-brand vc_welcome-visible-e vc_selected-post-custom-layout-visible-ne">
	<img src="<?php echo esc_url( vc_asset_url( 'vc/logo/wpb-logo.svg' ) ); ?>" alt="">
</div>
